/* =========================================================
   Script de eventos - Copa Mundial de la FIFA 2026
   Actividad Práctica III
   Eventos utilizados:
     1. click        -> cambiar tema claro/oscuro y volver arriba
     2. mouseenter / mouseleave -> resaltar tarjetas de datos
     3. input        -> filtrar la tabla de sedes
     4. scroll       -> barra de progreso y botón "volver arriba"
     5. keydown      -> atajos de teclado (T = tema, Esc = limpiar búsqueda)
   ========================================================= */

document.addEventListener('DOMContentLoaded', function () {

  var raiz = document.documentElement;
  var btnTema = document.getElementById('btn-tema');

  /* ---------- EVENTO 1: click (cambiar tema) ---------- */
  function actualizarTexto(){
    var oscuro = raiz.getAttribute('data-theme') === 'dark';
    btnTema.textContent = oscuro ? '☀️ Modo claro' : '🌙 Modo oscuro';
  }

  function cambiarTema(){
    var oscuro = raiz.getAttribute('data-theme') === 'dark';
    raiz.setAttribute('data-theme', oscuro ? 'light' : 'dark');
    actualizarTexto();
  }

  // Tema inicial según la preferencia del sistema
  if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
    raiz.setAttribute('data-theme', 'dark');
  }
  actualizarTexto();
  btnTema.addEventListener('click', cambiarTema);

  /* ---------- EVENTO 2: mouseenter / mouseleave (tarjetas) ---------- */
  var tarjetas = document.querySelectorAll('.dato');
  var infoDato = document.getElementById('info-dato');
  var textoInicial = infoDato.textContent;

  tarjetas.forEach(function (tarjeta) {
    tarjeta.addEventListener('mouseenter', function () {
      tarjeta.classList.add('activo');
      infoDato.textContent = tarjeta.dataset.info;
    });
    tarjeta.addEventListener('mouseleave', function () {
      tarjeta.classList.remove('activo');
      infoDato.textContent = textoInicial;
    });
  });

  /* ---------- EVENTO 3: input (filtrar tabla) ---------- */
  var buscador = document.getElementById('buscador');
  var filas = document.querySelectorAll('table tr:not(:first-child)');
  var sinResultados = document.getElementById('sin-resultados');

  function filtrar(){
    var texto = buscador.value.trim().toLowerCase();
    var visibles = 0;
    filas.forEach(function (fila) {
      var coincide = fila.textContent.toLowerCase().indexOf(texto) !== -1;
      fila.classList.toggle('oculta', !coincide);
      if (coincide) visibles++;
    });
    sinResultados.hidden = visibles !== 0;
  }
  buscador.addEventListener('input', filtrar);

  /* ---------- EVENTO 4: scroll (progreso y botón subir) ---------- */
  var barra = document.getElementById('barra-progreso');
  var btnSubir = document.getElementById('btn-subir');

  window.addEventListener('scroll', function () {
    var alto = document.documentElement.scrollHeight - window.innerHeight;
    var porcentaje = alto > 0 ? (window.scrollY / alto) * 100 : 0;
    barra.style.width = porcentaje + '%';
    btnSubir.hidden = window.scrollY < 300;
  });

  // (usa también click) volver al inicio de la página
  btnSubir.addEventListener('click', function () {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  /* ---------- EVENTO 5: keydown (atajos de teclado) ---------- */
  // Esc dentro del buscador: limpia el filtro
  buscador.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') {
      buscador.value = '';
      filtrar();
    }
  });

  // Tecla "T" en cualquier parte de la página: cambia el tema
  document.addEventListener('keydown', function (e) {
    var escribiendo = document.activeElement === buscador;
    if (!escribiendo && e.key.toLowerCase() === 't') {
      cambiarTema();
    }
  });

});
